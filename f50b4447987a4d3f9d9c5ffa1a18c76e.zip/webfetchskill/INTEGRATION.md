# Wire WebFetchSkill into your backend (FastAPI example — adapt to Flask if needed)
# Add this to main.py / agent_local.py alongside your other skill endpoints.

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from web_fetch import fetch  # the module above

app = FastAPI()  # or use your existing app instance


class WebFetchRequest(BaseModel):
    url: str
    max_chars: int = 8000


@app.post("/api/skills/web_fetch")
def web_fetch_endpoint(req: WebFetchRequest):
    result = fetch(req.url, max_chars=min(req.max_chars, 20000))
    if not result["ok"]:
        # 200 with ok:false so the agent sees the error code; adjust if you prefer 4xx
        return result
    return result


# --- Frontend helper (save as src/api/webFetch.js) ---
# export async function webFetch(url, maxChars = 8000) {
#   const res = await fetch("/api/skills/web_fetch", {
#     method: "POST",
#     headers: { "Content-Type": "application/json" },
#     body: JSON.stringify({ url, max_chars: maxChars }),
#   });
#   return res.json();
# }
#
# --- Flask equivalent ---
# @app.route("/api/skills/web_fetch", methods=["POST"])
# def web_fetch_endpoint():
#     data = request.get_json(force=True)
#     return jsonify(fetch(data.get("url",""), min(data.get("max_chars",8000), 20000)))
