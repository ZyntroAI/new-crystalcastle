"""
web_fetch.py — stdlib-only URL fetcher + main-text extractor for WebFetchSkill.
No pip dependencies. Optionally uses `trafilatura` or `bs4` if installed for
better extraction, but degrades gracefully to a built-in HTML parser.

Usage:
    from web_fetch import fetch
    result = fetch("https://example.com/article", max_chars=8000)
    # -> {"ok": True, "url", "title", "text", "char_count", "truncated", "fetch_time_ms"}
    # or {"ok": False, "error": "..."}
"""

import gzip
import re
import time
import urllib.request
import urllib.error
from html.parser import HTMLParser
from urllib.parse import urlparse

MAX_BYTES = 2 * 1024 * 1024  # read at most 2 MB of raw response
TIMEOUT = 15
USER_AGENT = (
    "Mozilla/5.0 (compatible; ZyntroAI-WebFetch/1.0; +https://zyntro.ai)"
)

_BLOCK_TAGS = {
    "p", "div", "br", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6",
    "tr", "td", "th", "section", "article", "header", "footer", "blockquote",
    "pre",
}
_SKIP_TAGS = {"script", "style", "noscript", "svg", "canvas", "iframe", "head"}


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self._skip = 0
        self._in_title = False
        self._title_parts = []
        self._parts = []

    def handle_starttag(self, tag, attrs):
        if tag in _SKIP_TAGS:
            self._skip += 1
        if tag == "title":
            self._in_title = True
        if tag in _BLOCK_TAGS:
            self._parts.append("\n")

    def handle_endtag(self, tag):
        if tag in _SKIP_TAGS:
            self._skip = max(0, self._skip - 1)
        if tag == "title":
            self._in_title = False
        if tag in _BLOCK_TAGS:
            self._parts.append("\n")

    def handle_data(self, data):
        if self._skip > 0:
            return
        if self._in_title:
            self._title_parts.append(data)
            return
        self._parts.append(data)

    @property
    def title(self):
        return re.sub(r"\s+", " ", "".join(self._title_parts)).strip()

    @property
    def text(self):
        raw = "".join(self._parts)
        # normalize whitespace per line, drop empty/very short lines
        lines = []
        for line in raw.splitlines():
            line = re.sub(r"[ \t]+", " ", line).strip()
            if len(line) >= 2:
                lines.append(line)
        return "\n".join(lines)


def _is_public_url(url: str) -> bool:
    try:
        p = urlparse(url)
    except Exception:
        return False
    if p.scheme not in ("http", "https"):
        return False
    host = (p.hostname or "").lower()
    if host in ("localhost", "127.0.0.1", "0.0.0.0") or host.endswith(".local"):
        return False
    if host.startswith("192.168.") or host.startswith("10.") or re.match(
        r"^172\.(1[6-9]|2\d|3[01])\.", host
    ):
        return False
    return True


def _extract_with_trafilatura(raw: bytes, url: str):
    try:
        import trafilatura  # type: ignore
    except Exception:
        return None
    try:
        text = trafilatura.extract(
            raw, url=url, include_comments=False, include_tables=False
        )
        meta = trafilatura.extract_metadata(raw, url=url) if hasattr(
            trafilatura, "extract_metadata"
        ) else None
        title = getattr(meta, "title", None) if meta else None
        if text:
            return title or "", text
    except Exception:
        return None
    return None


def fetch(url: str, max_chars: int = 8000):
    started = time.time()
    url = (url or "").strip()

    if not _is_public_url(url):
        return {"ok": False, "error": "invalid_or_private_url"}

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
            "Accept-Encoding": "gzip",
            "Accept-Language": "en-US,en;q=0.9,*;q=0.5",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            content_type = resp.headers.get("Content-Type", "").lower()
            if "html" not in content_type and "xml" not in content_type:
                return {
                    "ok": False,
                    "error": f"non_html:{content_type.split(';')[0] or 'unknown'}",
                }
            raw = resp.read(MAX_BYTES)
            charset = resp.headers.get_content_charset() or "utf-8"
            if resp.headers.get("Content-Encoding") == "gzip":
                try:
                    raw = gzip.decompress(raw)
                except Exception:
                    pass
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"http_{e.code}"}
    except urllib.error.URLError as e:
        return {"ok": False, "error": f"network_error:{type(e.reason).__name__}"}
    except TimeoutError:
        return {"ok": False, "error": "timeout"}
    except Exception as e:
        return {"ok": False, "error": f"fetch_error:{type(e).__name__}"}

    # Prefer trafilatura if installed; fall back to stdlib parser.
    extracted = _extract_with_trafilatura(raw, url)
    if extracted:
        title, text = extracted
    else:
        try:
            html = raw.decode(charset, errors="replace")
        except Exception:
            html = raw.decode("utf-8", errors="replace")
        parser = _TextExtractor()
        try:
            parser.feed(html)
        except Exception:
            pass
        title, text = parser.title, parser.text

    text = text.strip()
    truncated = len(text) > max_chars
    if truncated:
        text = text[:max_chars] + "\n…[truncated]"

    return {
        "ok": True,
        "url": url,
        "title": title or urlparse(url).netloc,
        "text": text,
        "char_count": len(text),
        "truncated": truncated,
        "fetch_time_ms": int((time.time() - started) * 1000),
    }


if __name__ == "__main__":
    import sys, json
    print(json.dumps(fetch(sys.argv[1] if len(sys.argv) > 1 else "https://example.com"),
                     indent=2, ensure_ascii=False))
