import { View, Text, ScrollView, Pressable, ActivityIndicator, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { useRouter } from "expo-router";

interface OnboardingInstance {
  id: number;
  newHireId: number;
  managerId: number;
  programId: number;
  startDate: Date;
  expectedEndDate?: Date;
  status: string;
  progressPercentage: number;
  createdAt: Date;
  updatedAt: Date;
}

interface Task {
  id: number;
  onboardingInstanceId: number;
  title: string;
  description?: string;
  instructions?: string;
  priority: string;
  dueDate?: Date;
  status: string;
  assignedBy: number;
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export default function DashboardScreen() {
  const colors = useColors();
  const { user } = useAuth();
  const router = useRouter();
  const [selectedInstance, setSelectedInstance] = useState<OnboardingInstance | null>(null);

  // Fetch onboarding instances
  const { data: instances, isLoading: instancesLoading } = trpc.onboarding.list.useQuery();

  // Fetch tasks for selected instance
  const { data: tasks = [], isLoading: tasksLoading } = trpc.tasks.list.useQuery(
    { instanceId: selectedInstance?.id || 0 },
    { enabled: !!selectedInstance }
  );

  // Fetch progress for selected instance
  const { data: progress = 0 } = trpc.onboarding.getProgress.useQuery(
    { instanceId: selectedInstance?.id || 0 },
    { enabled: !!selectedInstance }
  );

  // Set first instance as selected on load
  useEffect(() => {
    if (instances && instances.length > 0 && !selectedInstance) {
      setSelectedInstance(instances[0]);
    }
  }, [instances]);

  const pendingTasks = tasks.filter((t: Task) => t.status === "pending" || t.status === "in_progress");
  const completedTasks = tasks.filter((t: Task) => t.status === "approved");

  const handleTaskPress = (task: Task) => {
    router.push({
      pathname: "/dashboard",
      params: { taskId: task.id, instanceId: selectedInstance?.id },
    });
  };

  if (!user) {
    return (
      <ScreenContainer className="justify-center items-center">
        <Text className="text-foreground">Please log in</Text>
      </ScreenContainer>
    );
  }

  if (instancesLoading) {
    return (
      <ScreenContainer className="justify-center items-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  if (!instances || instances.length === 0) {
    return (
      <ScreenContainer className="justify-center items-center px-6">
        <View className="items-center gap-4">
          <Text className="text-2xl font-bold text-foreground">No Onboarding Found</Text>
          <Text className="text-sm text-muted text-center">
            Your manager will start your onboarding process soon. Check back later!
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="px-4 py-6">
        {/* Header */}
        <View className="gap-2 mb-6">
          <Text className="text-3xl font-bold text-foreground">Welcome, {user.name || "New Hire"}!</Text>
          <Text className="text-sm text-muted">Your onboarding journey starts here</Text>
        </View>

        {/* Instance Selector */}
        {instances.length > 1 && (
          <View className="mb-6">
            <Text className="text-sm font-semibold text-foreground mb-2">Select Onboarding Program</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
              {instances.map((instance: OnboardingInstance) => (
                <Pressable
                  key={instance.id}
                  onPress={() => setSelectedInstance(instance)}
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.8 : 1,
                    backgroundColor:
                      selectedInstance?.id === instance.id ? colors.primary : colors.surface,
                  })}
                  className="px-4 py-2 rounded-full border border-border"
                >
                  <Text
                    className={`text-sm font-semibold ${
                      selectedInstance?.id === instance.id ? "text-background" : "text-foreground"
                    }`}
                  >
                    Program {instance.id}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}

        {selectedInstance && (
          <>
            {/* Progress Card */}
            <View className="bg-surface rounded-2xl p-6 mb-6 border border-border">
              <View className="gap-3">
                <View className="flex-row justify-between items-center">
                  <Text className="text-lg font-semibold text-foreground">Onboarding Progress</Text>
                  <Text className="text-2xl font-bold text-primary">{progress}%</Text>
                </View>

                {/* Progress Bar */}
                <View className="h-2 bg-border rounded-full overflow-hidden">
                  <View
                    style={{ width: `${progress}%` }}
                    className="h-full bg-primary rounded-full"
                  />
                </View>

                <View className="flex-row justify-between text-xs text-muted">
                  <Text className="text-xs text-muted">
                    {completedTasks.length} of {tasks.length} tasks completed
                  </Text>
                  <Text className="text-xs text-muted">
                    Started{" "}
                    {new Date(selectedInstance.startDate).toLocaleDateString()}
                  </Text>
                </View>
              </View>
            </View>

            {/* Quick Stats */}
            <View className="flex-row gap-3 mb-6">
              <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
                <Text className="text-2xl font-bold text-primary">{pendingTasks.length}</Text>
                <Text className="text-xs text-muted mt-1">Pending Tasks</Text>
              </View>
              <View className="flex-1 bg-surface rounded-lg p-4 border border-border">
                <Text className="text-2xl font-bold text-success">{completedTasks.length}</Text>
                <Text className="text-xs text-muted mt-1">Completed</Text>
              </View>
            </View>

            {/* Pending Tasks */}
            {pendingTasks.length > 0 && (
              <View className="gap-3 mb-6">
                <Text className="text-lg font-semibold text-foreground">Pending Tasks</Text>
                <FlatList
                  data={pendingTasks}
                  keyExtractor={(item: Task) => item.id.toString()}
                  scrollEnabled={false}
                  renderItem={({ item }: { item: Task }) => (
                    <Pressable
                      onPress={() => handleTaskPress(item)}
                      style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
                      className="bg-surface rounded-lg p-4 mb-3 border border-border"
                    >
                      <View className="gap-2">
                        <View className="flex-row justify-between items-start">
                          <Text className="text-sm font-semibold text-foreground flex-1">
                            {item.title}
                          </Text>
                          <View
                            className={`px-2 py-1 rounded ${
                              item.priority === "high"
                                ? "bg-error"
                                : item.priority === "medium"
                                  ? "bg-warning"
                                  : "bg-border"
                            }`}
                          >
                            <Text className="text-xs font-semibold text-background">
                              {item.priority}
                            </Text>
                          </View>
                        </View>
                        {item.description && (
                          <Text className="text-xs text-muted line-clamp-2">
                            {item.description}
                          </Text>
                        )}
                        {item.dueDate && (
                          <Text className="text-xs text-muted">
                            Due: {new Date(item.dueDate).toLocaleDateString()}
                          </Text>
                        )}
                      </View>
                    </Pressable>
                  )}
                />
              </View>
            )}

            {/* All Tasks Button */}
            <Pressable
              onPress={() =>
                router.push({
                  pathname: "/dashboard",
                  params: { instanceId: selectedInstance.id },
                })
              }
              style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              className="bg-primary rounded-lg py-3 items-center"
            >
              <Text className="text-sm font-semibold text-background">View All Tasks</Text>
            </Pressable>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
