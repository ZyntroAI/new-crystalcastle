import { View, Text, Pressable, ScrollView, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { useAuth } from "@/hooks/use-auth";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function RoleSelectionScreen() {
  const router = useRouter();
  const colors = useColors();
  const { user } = useAuth();
  const [selectedRole, setSelectedRole] = useState<"new_hire" | "manager" | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const addRoleMutation = trpc.roles.add.useMutation({
    onSuccess: () => {
      if (selectedRole === "new_hire") {
        router.replace("/");
      } else if (selectedRole === "manager") {
        router.replace("/");
      }
    },
    onError: (error) => {
      console.error("Failed to set role:", error);
      setIsLoading(false);
    },
  });

  const handleRoleSelect = async (role: "new_hire" | "manager") => {
    if (!user) return;
    
    setSelectedRole(role);
    setIsLoading(true);

    try {
      await addRoleMutation.mutateAsync({
        userId: user.id,
        role,
        department: undefined,
      });
    } catch (error) {
      console.error("Error setting role:", error);
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1 justify-center items-center px-6 py-12 gap-8">
          {/* Header */}
          <View className="items-center gap-2">
            <Text className="text-4xl font-bold text-foreground">Welcome to OnboardHub</Text>
            <Text className="text-base text-muted text-center">
              Select your role to get started
            </Text>
          </View>

          {/* Role Cards */}
          <View className="w-full gap-4">
            {/* New Hire Card */}
            <Pressable
              onPress={() => handleRoleSelect("new_hire")}
              disabled={isLoading}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                  backgroundColor: selectedRole === "new_hire" ? colors.primary : colors.surface,
                  borderColor: selectedRole === "new_hire" ? colors.primary : colors.border,
                },
              ]}
              className="rounded-2xl p-6 border border-border"
            >
              <View className="gap-3">
                <Text className="text-2xl font-bold text-foreground">👤 New Hire</Text>
                <Text className="text-sm text-muted">
                  Complete your onboarding tasks, upload documents, and attend training sessions
                </Text>
                {selectedRole === "new_hire" && (
                  <View className="flex-row items-center gap-2 mt-2">
                    {isLoading ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <Text className="text-sm font-semibold text-primary">✓ Selected</Text>
                    )}
                  </View>
                )}
              </View>
            </Pressable>

            {/* Manager Card */}
            <Pressable
              onPress={() => handleRoleSelect("manager")}
              disabled={isLoading}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                  backgroundColor: selectedRole === "manager" ? colors.primary : colors.surface,
                  borderColor: selectedRole === "manager" ? colors.primary : colors.border,
                },
              ]}
              className="rounded-2xl p-6 border border-border"
            >
              <View className="gap-3">
                <Text className="text-2xl font-bold text-foreground">👨‍💼 Manager</Text>
                <Text className="text-sm text-muted">
                  Manage team onboarding, review submissions, and track progress
                </Text>
                {selectedRole === "manager" && (
                  <View className="flex-row items-center gap-2 mt-2">
                    {isLoading ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <Text className="text-sm font-semibold text-primary">✓ Selected</Text>
                    )}
                  </View>
                )}
              </View>
            </Pressable>
          </View>

          {/* Info Box */}
          <View className="w-full bg-surface rounded-lg p-4 border border-border">
            <Text className="text-xs text-muted">
              💡 You can change your role later in settings. If you have multiple roles, you'll be able to switch between them.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
