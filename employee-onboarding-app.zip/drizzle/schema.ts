import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Employee Onboarding Schema
 * Supports role-based onboarding with task assignments, document collection,
 * training schedules, and manager approval workflows.
 */

// User roles for the onboarding system
export const userRoles = mysqlTable("userRoles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["new_hire", "manager", "admin"]).notNull(),
  department: varchar("department", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserRole = typeof userRoles.$inferSelect;
export type InsertUserRole = typeof userRoles.$inferInsert;

// Onboarding programs/templates
export const onboardingPrograms = mysqlTable("onboardingPrograms", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  durationDays: int("durationDays").default(30).notNull(),
  roleTemplate: varchar("roleTemplate", { length: 255 }).notNull(), // e.g., "engineer", "manager", "sales"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OnboardingProgram = typeof onboardingPrograms.$inferSelect;
export type InsertOnboardingProgram = typeof onboardingPrograms.$inferInsert;

// Onboarding instances for each new hire
export const onboardingInstances = mysqlTable("onboardingInstances", {
  id: int("id").autoincrement().primaryKey(),
  newHireId: int("newHireId").notNull(),
  managerId: int("managerId").notNull(),
  programId: int("programId").notNull(),
  startDate: timestamp("startDate").defaultNow().notNull(),
  expectedEndDate: timestamp("expectedEndDate"),
  status: mysqlEnum("status", ["not_started", "in_progress", "completed", "paused"]).default("not_started").notNull(),
  progressPercentage: int("progressPercentage").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OnboardingInstance = typeof onboardingInstances.$inferSelect;
export type InsertOnboardingInstance = typeof onboardingInstances.$inferInsert;

// Tasks assigned to new hires
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  onboardingInstanceId: int("onboardingInstanceId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  instructions: text("instructions"),
  priority: mysqlEnum("priority", ["low", "medium", "high"]).default("medium").notNull(),
  dueDate: timestamp("dueDate"),
  status: mysqlEnum("status", ["pending", "in_progress", "submitted", "approved", "rejected"]).default("pending").notNull(),
  assignedBy: int("assignedBy").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

// Task submissions for approval
export const taskSubmissions = mysqlTable("taskSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  submittedBy: int("submittedBy").notNull(),
  notes: text("notes"),
  evidenceUrl: varchar("evidenceUrl", { length: 2048 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  reviewedBy: int("reviewedBy"),
  reviewFeedback: text("reviewFeedback"),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export type TaskSubmission = typeof taskSubmissions.$inferSelect;
export type InsertTaskSubmission = typeof taskSubmissions.$inferInsert;

// Required documents for onboarding
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  onboardingInstanceId: int("onboardingInstanceId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(), // e.g., "id", "tax_form", "contract"
  required: boolean("required").default(true).notNull(),
  status: mysqlEnum("status", ["pending", "uploaded", "approved", "rejected"]).default("pending").notNull(),
  fileUrl: varchar("fileUrl", { length: 2048 }),
  uploadedBy: int("uploadedBy"),
  uploadedAt: timestamp("uploadedAt"),
  reviewedBy: int("reviewedBy"),
  reviewFeedback: text("reviewFeedback"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

// Training sessions
export const trainingSessions = mysqlTable("trainingSessions", {
  id: int("id").autoincrement().primaryKey(),
  onboardingInstanceId: int("onboardingInstanceId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  trainer: varchar("trainer", { length: 255 }),
  trainerEmail: varchar("trainerEmail", { length: 320 }),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  location: varchar("location", { length: 255 }),
  meetingLink: varchar("meetingLink", { length: 2048 }),
  materialsUrl: varchar("materialsUrl", { length: 2048 }),
  status: mysqlEnum("status", ["scheduled", "in_progress", "completed", "cancelled"]).default("scheduled").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TrainingSession = typeof trainingSessions.$inferSelect;
export type InsertTrainingSession = typeof trainingSessions.$inferInsert;

// Training attendance tracking
export const trainingAttendance = mysqlTable("trainingAttendance", {
  id: int("id").autoincrement().primaryKey(),
  trainingSessionId: int("trainingSessionId").notNull(),
  attendeeId: int("attendeeId").notNull(),
  status: mysqlEnum("status", ["registered", "attended", "absent", "excused"]).default("registered").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TrainingAttendance = typeof trainingAttendance.$inferSelect;
export type InsertTrainingAttendance = typeof trainingAttendance.$inferInsert;

// Approvals workflow
export const approvals = mysqlTable("approvals", {
  id: int("id").autoincrement().primaryKey(),
  onboardingInstanceId: int("onboardingInstanceId").notNull(),
  type: mysqlEnum("type", ["task", "document"]).notNull(),
  referenceId: int("referenceId").notNull(), // taskSubmissionId or documentId
  submittedBy: int("submittedBy").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  reviewedBy: int("reviewedBy"),
  feedback: text("feedback"),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export type Approval = typeof approvals.$inferSelect;
export type InsertApproval = typeof approvals.$inferInsert;

// Notifications for users
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 100 }).notNull(), // e.g., "task_assigned", "approval_needed", "document_approved"
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  referenceId: int("referenceId"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
