CREATE TABLE `approvals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`onboardingInstanceId` int NOT NULL,
	`type` enum('task','document') NOT NULL,
	`referenceId` int NOT NULL,
	`submittedBy` int NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewedBy` int,
	`feedback` text,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `approvals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`onboardingInstanceId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` varchar(100) NOT NULL,
	`required` boolean NOT NULL DEFAULT true,
	`status` enum('pending','uploaded','approved','rejected') NOT NULL DEFAULT 'pending',
	`fileUrl` varchar(2048),
	`uploadedBy` int,
	`uploadedAt` timestamp,
	`reviewedBy` int,
	`reviewFeedback` text,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` varchar(100) NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text,
	`referenceId` int,
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `onboardingInstances` (
	`id` int AUTO_INCREMENT NOT NULL,
	`newHireId` int NOT NULL,
	`managerId` int NOT NULL,
	`programId` int NOT NULL,
	`startDate` timestamp NOT NULL DEFAULT (now()),
	`expectedEndDate` timestamp,
	`status` enum('not_started','in_progress','completed','paused') NOT NULL DEFAULT 'not_started',
	`progressPercentage` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `onboardingInstances_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `onboardingPrograms` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`durationDays` int NOT NULL DEFAULT 30,
	`roleTemplate` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `onboardingPrograms_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `taskSubmissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`taskId` int NOT NULL,
	`submittedBy` int NOT NULL,
	`notes` text,
	`evidenceUrl` varchar(2048),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewedBy` int,
	`reviewFeedback` text,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `taskSubmissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`onboardingInstanceId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`instructions` text,
	`priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
	`dueDate` timestamp,
	`status` enum('pending','in_progress','submitted','approved','rejected') NOT NULL DEFAULT 'pending',
	`assignedBy` int NOT NULL,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trainingAttendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`trainingSessionId` int NOT NULL,
	`attendeeId` int NOT NULL,
	`status` enum('registered','attended','absent','excused') NOT NULL DEFAULT 'registered',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trainingAttendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trainingSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`onboardingInstanceId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`trainer` varchar(255),
	`trainerEmail` varchar(320),
	`startDate` timestamp NOT NULL,
	`endDate` timestamp,
	`location` varchar(255),
	`meetingLink` varchar(2048),
	`materialsUrl` varchar(2048),
	`status` enum('scheduled','in_progress','completed','cancelled') NOT NULL DEFAULT 'scheduled',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trainingSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userRoles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`role` enum('new_hire','manager','admin') NOT NULL,
	`department` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userRoles_id` PRIMARY KEY(`id`)
);
