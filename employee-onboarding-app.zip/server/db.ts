import { eq, and, desc, asc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "../drizzle/schema";
import {
  users,
  userRoles,
  onboardingPrograms,
  onboardingInstances,
  tasks,
  taskSubmissions,
  documents,
  trainingSessions,
  trainingAttendance,
  approvals,
  notifications,
  type InsertUserRole,
  type InsertOnboardingProgram,
  type InsertOnboardingInstance,
  type InsertTask,
  type InsertTaskSubmission,
  type InsertDocument,
  type InsertTrainingSession,
  type InsertTrainingAttendance,
  type InsertApproval,
  type InsertNotification,
} from "../drizzle/schema";

// ============================================================================
// User Management
// ============================================================================

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(users).where(eq(users.openId, openId));
  return result[0] || null;
}

export async function upsertUser(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existingUser = await getUserByOpenId(data.openId);
  
  if (existingUser) {
    await db
      .update(users)
      .set({
        name: data.name ?? existingUser.name,
        email: data.email ?? existingUser.email,
        loginMethod: data.loginMethod ?? existingUser.loginMethod,
        lastSignedIn: data.lastSignedIn ?? existingUser.lastSignedIn,
        updatedAt: new Date(),
      })
      .where(eq(users.openId, data.openId));
    return getUserByOpenId(data.openId);
  } else {
    const result = await db.insert(users).values({
      openId: data.openId,
      name: data.name || null,
      email: data.email || null,
      loginMethod: data.loginMethod || null,
      role: "user",
      lastSignedIn: data.lastSignedIn || new Date(),
    });
    return getUserByOpenId(data.openId);
  }
}

// ============================================================================
// User Role Management
// ============================================================================

export async function getUserRoles(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userRoles).where(eq(userRoles.userId, userId));
}

export async function addUserRole(data: InsertUserRole) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(userRoles).values(data);
  return result.insertId;
}

// ============================================================================
// Onboarding Program Management
// ============================================================================

export async function getOnboardingPrograms() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(onboardingPrograms);
}

export async function getOnboardingProgramById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(onboardingPrograms)
    .where(eq(onboardingPrograms.id, id));
  return result[0] || null;
}

export async function createOnboardingProgram(data: InsertOnboardingProgram) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(onboardingPrograms).values(data);
  return result.insertId;
}

// ============================================================================
// Onboarding Instance Management
// ============================================================================

export async function getOnboardingInstances(userId: number, role: string) {
  const db = await getDb();
  if (!db) return [];

  if (role === "new_hire") {
    return db
      .select()
      .from(onboardingInstances)
      .where(eq(onboardingInstances.newHireId, userId));
  } else if (role === "manager") {
    return db
      .select()
      .from(onboardingInstances)
      .where(eq(onboardingInstances.managerId, userId));
  }
  return [];
}

export async function getOnboardingInstanceById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(onboardingInstances)
    .where(eq(onboardingInstances.id, id));
  return result[0] || null;
}

export async function createOnboardingInstance(data: InsertOnboardingInstance) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(onboardingInstances).values(data);
  return result.insertId;
}

export async function updateOnboardingInstanceProgress(
  id: number,
  progressPercentage: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(onboardingInstances)
    .set({ progressPercentage })
    .where(eq(onboardingInstances.id, id));
}

// ============================================================================
// Task Management
// ============================================================================

export async function getTasksByOnboardingInstance(instanceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(tasks)
    .where(eq(tasks.onboardingInstanceId, instanceId))
    .orderBy(desc(tasks.priority), asc(tasks.dueDate));
}

export async function getTaskById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(tasks).where(eq(tasks.id, id));
  return result[0] || null;
}

export async function createTask(data: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(tasks).values(data);
  return result.insertId;
}

export async function updateTaskStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tasks).set({ status }).where(eq(tasks.id, id));
}

export async function getPendingTasks(instanceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(tasks)
    .where(
      and(
        eq(tasks.onboardingInstanceId, instanceId),
        eq(tasks.status, "pending")
      )
    );
}

// ============================================================================
// Task Submission Management
// ============================================================================

export async function createTaskSubmission(data: InsertTaskSubmission) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(taskSubmissions).values(data);
  return result.insertId;
}

export async function getTaskSubmissionsByTask(taskId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(taskSubmissions)
    .where(eq(taskSubmissions.taskId, taskId))
    .orderBy(desc(taskSubmissions.submittedAt));
}

export async function approveTaskSubmission(
  id: number,
  reviewedBy: number,
  feedback?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(taskSubmissions)
    .set({
      status: "approved",
      reviewedBy,
      reviewFeedback: feedback,
      reviewedAt: new Date(),
    })
    .where(eq(taskSubmissions.id, id));
}

export async function rejectTaskSubmission(
  id: number,
  reviewedBy: number,
  feedback: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(taskSubmissions)
    .set({
      status: "rejected",
      reviewedBy,
      reviewFeedback: feedback,
      reviewedAt: new Date(),
    })
    .where(eq(taskSubmissions.id, id));
}

// ============================================================================
// Document Management
// ============================================================================

export async function getDocumentsByOnboardingInstance(instanceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(documents)
    .where(eq(documents.onboardingInstanceId, instanceId));
}

export async function getDocumentById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(documents).where(eq(documents.id, id));
  return result[0] || null;
}

export async function createDocument(data: InsertDocument) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(documents).values(data);
  return result.insertId;
}

export async function updateDocumentStatus(
  id: number,
  status: string,
  fileUrl?: string,
  uploadedBy?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(documents)
    .set({
      status,
      fileUrl: fileUrl || undefined,
      uploadedBy: uploadedBy || undefined,
      uploadedAt: uploadedBy ? new Date() : undefined,
    })
    .where(eq(documents.id, id));
}

export async function approveDocument(
  id: number,
  reviewedBy: number,
  feedback?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(documents)
    .set({
      status: "approved",
      reviewedBy,
      reviewFeedback: feedback,
      reviewedAt: new Date(),
    })
    .where(eq(documents.id, id));
}

export async function rejectDocument(
  id: number,
  reviewedBy: number,
  feedback: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(documents)
    .set({
      status: "rejected",
      reviewedBy,
      reviewFeedback: feedback,
      reviewedAt: new Date(),
    })
    .where(eq(documents.id, id));
}

export async function getPendingDocuments(instanceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(documents)
    .where(
      and(
        eq(documents.onboardingInstanceId, instanceId),
        eq(documents.status, "pending")
      )
    );
}

// ============================================================================
// Training Session Management
// ============================================================================

export async function getTrainingSessionsByOnboardingInstance(
  instanceId: number
) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(trainingSessions)
    .where(eq(trainingSessions.onboardingInstanceId, instanceId))
    .orderBy(asc(trainingSessions.startDate));
}

export async function getTrainingSessionById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(trainingSessions)
    .where(eq(trainingSessions.id, id));
  return result[0] || null;
}

export async function createTrainingSession(data: InsertTrainingSession) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(trainingSessions).values(data);
  return result.insertId;
}

export async function updateTrainingSessionStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(trainingSessions)
    .set({ status })
    .where(eq(trainingSessions.id, id));
}

// ============================================================================
// Training Attendance Management
// ============================================================================

export async function getTrainingAttendance(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(trainingAttendance)
    .where(eq(trainingAttendance.trainingSessionId, sessionId));
}

export async function createTrainingAttendance(data: InsertTrainingAttendance) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(trainingAttendance).values(data);
  return result.insertId;
}

export async function updateAttendanceStatus(
  id: number,
  status: string,
  notes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(trainingAttendance)
    .set({ status, notes })
    .where(eq(trainingAttendance.id, id));
}

// ============================================================================
// Approval Management
// ============================================================================

export async function getPendingApprovals(managerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(approvals)
    .where(eq(approvals.status, "pending"))
    .orderBy(desc(approvals.submittedAt));
}

export async function getApprovalsByOnboardingInstance(instanceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(approvals)
    .where(eq(approvals.onboardingInstanceId, instanceId));
}

export async function createApproval(data: InsertApproval) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(approvals).values(data);
  return result.insertId;
}

export async function approveApproval(
  id: number,
  reviewedBy: number,
  feedback?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(approvals)
    .set({
      status: "approved",
      reviewedBy,
      feedback,
      reviewedAt: new Date(),
    })
    .where(eq(approvals.id, id));
}

export async function rejectApproval(
  id: number,
  reviewedBy: number,
  feedback: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(approvals)
    .set({
      status: "rejected",
      reviewedBy,
      feedback,
      reviewedAt: new Date(),
    })
    .where(eq(approvals.id, id));
}

// ============================================================================
// Notification Management
// ============================================================================

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(notifications).values(data);
  return result.insertId;
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(notifications)
    .set({ read: true })
    .where(eq(notifications.id, id));
}

// ============================================================================
// Progress Calculation
// ============================================================================

// ============================================================================
// Database Connection Helper
// ============================================================================

let dbInstance: any = null;

async function getDb() {
  if (!dbInstance) {
    const pool = mysql.createPool({
      uri: process.env.DATABASE_URL,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
    dbInstance = drizzle(pool, { schema, mode: "default" });
  }
  return dbInstance;
}

// ============================================================================
// Progress Calculation
// ============================================================================

export async function calculateOnboardingProgress(instanceId: number) {
  const db = await getDb();
  if (!db) return 0;

  const allTasks = await db
    .select()
    .from(tasks)
    .where(eq(tasks.onboardingInstanceId, instanceId));

  const allDocuments = await db
    .select()
    .from(documents)
    .where(eq(documents.onboardingInstanceId, instanceId));

  const allTrainingSessions = await db
    .select()
    .from(trainingSessions)
    .where(eq(trainingSessions.onboardingInstanceId, instanceId));

  const completedTasks = allTasks.filter((t: any) => t.status === "approved").length;
  const approvedDocuments = allDocuments.filter(
    (d: any) => d.status === "approved"
  ).length;
  const completedTraining = allTrainingSessions.filter(
    (s: any) => s.status === "completed"
  ).length;

  const totalItems =
    allTasks.length + allDocuments.length + allTrainingSessions.length;
  const completedItems = completedTasks + approvedDocuments + completedTraining;

  return totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
}
