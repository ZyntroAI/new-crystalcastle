import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================================================
  // Onboarding Programs
  // ============================================================================
  programs: router({
    list: publicProcedure.query(() => db.getOnboardingPrograms()),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getOnboardingProgramById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          description: z.string().optional(),
          durationDays: z.number().int().positive().default(30),
          roleTemplate: z.string().min(1),
        })
      )
      .mutation(({ input }) => db.createOnboardingProgram(input)),
  }),

  // ============================================================================
  // Onboarding Instances
  // ============================================================================
  onboarding: router({
    list: protectedProcedure.query(({ ctx }) => {
      // Get user's role
      return db.getOnboardingInstances(ctx.user.id, "new_hire");
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getOnboardingInstanceById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          newHireId: z.number(),
          managerId: z.number(),
          programId: z.number(),
          expectedEndDate: z.date().optional(),
        })
      )
      .mutation(({ input }) => db.createOnboardingInstance(input)),

    getProgress: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.calculateOnboardingProgress(input.instanceId)),
  }),

  // ============================================================================
  // Tasks
  // ============================================================================
  tasks: router({
    list: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.getTasksByOnboardingInstance(input.instanceId)),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getTaskById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          onboardingInstanceId: z.number(),
          title: z.string().min(1),
          description: z.string().optional(),
          instructions: z.string().optional(),
          priority: z.enum(["low", "medium", "high"]).default("medium"),
          dueDate: z.date().optional(),
        })
      )
      .mutation(({ ctx, input }) => {
        return db.createTask({
          ...input,
          status: "pending",
          assignedBy: ctx.user.id,
        });
      }),

    submit: protectedProcedure
      .input(
        z.object({
          taskId: z.number(),
          notes: z.string().optional(),
          evidenceUrl: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const task = await db.getTaskById(input.taskId);
        if (!task) throw new Error("Task not found");

        // Update task status to submitted
        await db.updateTaskStatus(input.taskId, "submitted");

        // Create task submission
        const submissionId = await db.createTaskSubmission({
          taskId: input.taskId,
          submittedBy: ctx.user.id,
          notes: input.notes,
          evidenceUrl: input.evidenceUrl,
          status: "pending",
        });

        return submissionId;
      }),

    getPending: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.getPendingTasks(input.instanceId)),
  }),

  // ============================================================================
  // Task Submissions & Approvals
  // ============================================================================
  submissions: router({
    getByTask: protectedProcedure
      .input(z.object({ taskId: z.number() }))
      .query(({ input }) => db.getTaskSubmissionsByTask(input.taskId)),

    approve: protectedProcedure
      .input(
        z.object({
          submissionId: z.number(),
          feedback: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await db.approveTaskSubmission(
          input.submissionId,
          ctx.user.id,
          input.feedback
        );

        // Update the associated task status
        const submissions = await db.getTaskSubmissionsByTask(
          input.submissionId
        );
        if (submissions.length > 0) {
          await db.updateTaskStatus(submissions[0].taskId, "approved");
        }

        return { success: true };
      }),

    reject: protectedProcedure
      .input(
        z.object({
          submissionId: z.number(),
          feedback: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await db.rejectTaskSubmission(
          input.submissionId,
          ctx.user.id,
          input.feedback
        );

        // Update the associated task status back to pending
        const submissions = await db.getTaskSubmissionsByTask(
          input.submissionId
        );
        if (submissions.length > 0) {
          await db.updateTaskStatus(submissions[0].taskId, "pending");
        }

        return { success: true };
      }),
  }),

  // ============================================================================
  // Documents
  // ============================================================================
  documents: router({
    list: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.getDocumentsByOnboardingInstance(input.instanceId)),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getDocumentById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          onboardingInstanceId: z.number(),
          name: z.string().min(1),
          type: z.string().min(1),
          required: z.boolean().default(true),
        })
      )
      .mutation(({ input }) => db.createDocument(input)),

    upload: protectedProcedure
      .input(
        z.object({
          documentId: z.number(),
          fileUrl: z.string().url(),
        })
      )
      .mutation(({ ctx, input }) => {
        return db.updateDocumentStatus(
          input.documentId,
          "uploaded",
          input.fileUrl,
          ctx.user.id
        );
      }),

    approve: protectedProcedure
      .input(
        z.object({
          documentId: z.number(),
          feedback: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) => {
        return db.approveDocument(
          input.documentId,
          ctx.user.id,
          input.feedback
        );
      }),

    reject: protectedProcedure
      .input(
        z.object({
          documentId: z.number(),
          feedback: z.string().min(1),
        })
      )
      .mutation(({ ctx, input }) => {
        return db.rejectDocument(input.documentId, ctx.user.id, input.feedback);
      }),

    getPending: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.getPendingDocuments(input.instanceId)),
  }),

  // ============================================================================
  // Training Sessions
  // ============================================================================
  training: router({
    list: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) =>
        db.getTrainingSessionsByOnboardingInstance(input.instanceId)
      ),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getTrainingSessionById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          onboardingInstanceId: z.number(),
          title: z.string().min(1),
          description: z.string().optional(),
          trainer: z.string().optional(),
          trainerEmail: z.string().email().optional(),
          startDate: z.date(),
          endDate: z.date().optional(),
          location: z.string().optional(),
          meetingLink: z.string().url().optional(),
          materialsUrl: z.string().url().optional(),
        })
      )
      .mutation(({ input }) => db.createTrainingSession(input)),

    updateStatus: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          status: z.enum(["scheduled", "in_progress", "completed", "cancelled"]),
        })
      )
      .mutation(({ input }) =>
        db.updateTrainingSessionStatus(input.sessionId, input.status)
      ),
  }),

  // ============================================================================
  // Training Attendance
  // ============================================================================
  attendance: router({
    list: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(({ input }) => db.getTrainingAttendance(input.sessionId)),

    register: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(({ ctx, input }) => {
        return db.createTrainingAttendance({
          trainingSessionId: input.sessionId,
          attendeeId: ctx.user.id,
          status: "registered",
        });
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          attendanceId: z.number(),
          status: z.enum(["registered", "attended", "absent", "excused"]),
          notes: z.string().optional(),
        })
      )
      .mutation(({ input }) =>
        db.updateAttendanceStatus(
          input.attendanceId,
          input.status,
          input.notes
        )
      ),
  }),

  // ============================================================================
  // Approvals
  // ============================================================================
  approvals: router({
    getPending: protectedProcedure.query(({ ctx }) =>
      db.getPendingApprovals(ctx.user.id)
    ),

    getByInstance: protectedProcedure
      .input(z.object({ instanceId: z.number() }))
      .query(({ input }) => db.getApprovalsByOnboardingInstance(input.instanceId)),

    approve: protectedProcedure
      .input(
        z.object({
          approvalId: z.number(),
          feedback: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        db.approveApproval(input.approvalId, ctx.user.id, input.feedback)
      ),

    reject: protectedProcedure
      .input(
        z.object({
          approvalId: z.number(),
          feedback: z.string().min(1),
        })
      )
      .mutation(({ ctx, input }) =>
        db.rejectApproval(input.approvalId, ctx.user.id, input.feedback)
      ),
  }),

  // ============================================================================
  // Notifications
  // ============================================================================
  notifications: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.getUserNotifications(ctx.user.id)
    ),

    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(({ input }) => db.markNotificationAsRead(input.notificationId)),
  }),

  // ============================================================================
  // User Roles
  // ============================================================================
  roles: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserRoles(ctx.user.id)),

    add: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
          role: z.enum(["new_hire", "manager", "admin"]),
          department: z.string().optional(),
        })
      )
      .mutation(({ input }) => db.addUserRole(input)),
  }),
});

export type AppRouter = typeof appRouter;
