# Employee Onboarding App - TODO

## Phase 1: Project Setup & Design
- [x] Initialize Expo mobile app project
- [x] Create design document with screens and flows
- [x] Plan data models and architecture
- [x] Generate app logo and update branding

## Phase 2: Core Backend & Database
- [x] Design and implement database schema (users, tasks, documents, training, approvals)
- [x] Set up authentication routes (login, logout, role-based access)
- [x] Create user management API endpoints
- [x] Implement task management API (CRUD operations)
- [x] Implement document management API (upload, list, approve/reject)
- [x] Implement training schedule API (CRUD, attendance)
- [x] Implement approval workflow API (submit, review, approve/reject)
- [x] Add role-based access control middleware
- [x] Create comprehensive database helper functions
- [x] Create tRPC router with all API endpoints

## Phase 3: New Hire Screens
- [x] Build Login screen with email/password authentication
- [x] Build Role Selection screen
- [x] Build New Hire Dashboard with progress overview (in progress)
- [ ] Build Tasks screen with filtering and status display
- [ ] Build Task Detail screen with submission flow
- [ ] Build Documents screen with upload status
- [ ] Build Document Upload screen with file picker
- [ ] Build Training Schedule screen with calendar view
- [ ] Build Training Session Detail screen
- [ ] Build New Hire Profile screen

## Phase 4: Manager Screens
- [ ] Build Manager Dashboard with team overview
- [ ] Build Team Members screen with progress indicators
- [ ] Build New Hire Profile screen (manager view)
- [ ] Build Approvals screen with pending items queue
- [ ] Build Approval Detail screen with review interface
- [ ] Build Create Task screen with form validation
- [ ] Build Training Management screen

## Phase 5: Integration & Polish
- [ ] Implement push notifications for approvals and task assignments
- [ ] Add offline support with AsyncStorage caching
- [ ] Implement real-time updates for approvals
- [ ] Add progress tracking calculations
- [ ] Implement role-based navigation
- [ ] Add comprehensive error handling
- [ ] Implement loading states and skeleton screens
- [ ] Add haptic feedback and animations
- [ ] Test end-to-end user flows
- [ ] Optimize performance and bundle size

## Phase 6: Testing & Deployment
- [ ] Write unit tests for core business logic
- [ ] Write integration tests for API endpoints
- [ ] Test on iOS and Android devices
- [ ] Test dark mode compatibility
- [ ] Test accessibility features
- [ ] Create checkpoint for first delivery
- [ ] Deploy to production

## Branding
- [x] Generate custom app logo
- [x] Update app.config.ts with app name and logo URL
- [ ] Update color scheme in theme.config.js
- [ ] Verify icon appears in all required locations

## Known Issues & Improvements
- Navigation routes need to be created for task-detail and tasks screens
- Database connection needs to be tested with actual data
- Need to implement proper error handling for API calls
- Need to add loading skeletons for better UX
