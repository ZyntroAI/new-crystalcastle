#!/bin/bash
set -e
PY_VER="3.14.7"
echo "🐍 Installing Python $PY_VER..."

# Ubuntu/Debian
if command -v apt &> /dev/null; then
  sudo apt update
  sudo apt install -y software-properties-common
  sudo add-apt-repository ppa:deadsnakes/ppa -y
  sudo apt install -y python3.14 python3.14-venv python3-pip
fi

# macOS Homebrew
if command -v brew &> /dev/null; then
  brew install python@3.14
fi

# Verify & Upgrade Pip
python3.14 -m pip install --upgrade pip setuptools
pip3 install -r requirements.txt

echo "✅ Done: $(python3.14 --version)"
