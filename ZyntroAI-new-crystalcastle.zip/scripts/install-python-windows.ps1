$ErrorActionPreference = "Stop"
$PY_VER = "3.14.7"
$URI = "https://www.python.org/ftp/python/$PY_VER/python-$PY_VER-amd64.exe"

Write-Host "🐍 Installing Python $PY_VER..."
winget install Python.Python.3.14 --silent --include-launcher

# Refresh PATH
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + `
            [System.Environment]::GetEnvironmentVariable("Path","User")

python -m pip install --upgrade pip setuptools
pip install -r requirements.txt

Write-Host "✅ Done: $(python --version)"
