#!/usr/bin/env bash
# Smoke-test the built images. Asserts behaviour, not just exit codes.
#
#   scripts/ci/smoke-test.sh
set -euo pipefail
cd "$(dirname "$0")/../.."

pass=0; fail=0
ok()   { echo "  [PASS] $*"; pass=$((pass+1)); }
bad()  { echo "  [FAIL] $*"; fail=$((fail+1)); }

cleanup() { docker rm -f cc-smoke-web >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "== web image =="
if docker image inspect crystalcastle-web:local >/dev/null 2>&1; then
  docker run -d --name cc-smoke-web -p 3000:3000 -e NODE_ENV=production \
    crystalcastle-web:local >/dev/null

  ready=0
  for _ in $(seq 1 30); do
    if curl -fsS http://127.0.0.1:3000/ >/dev/null 2>&1; then ready=1; break; fi
    sleep 1
  done
  [ "$ready" = "1" ] && ok "responds on :3000 within 30s" \
                     || { bad "no response on :3000"; docker logs cc-smoke-web; }

  uid=$(docker exec cc-smoke-web id -u 2>/dev/null || echo x)
  [ "$uid" != "0" ] && ok "runs as non-root (uid=$uid)" || bad "runs as root (uid=$uid)"
else
  bad "crystalcastle-web:local not built"
fi

echo "== notify image =="
if docker image inspect crystalcastle-notify:local >/dev/null 2>&1; then
  uid=$(docker run --rm --entrypoint id crystalcastle-notify:local -u)
  [ "$uid" != "0" ] && ok "runs as non-root (uid=$uid)" || bad "runs as root"
  docker run --rm --entrypoint node crystalcastle-notify:local \
    -e "process.exit(require('fs').existsSync('src/index.js')?0:1)" \
    && ok "src/index.js present in image" || bad "src/index.js missing"
else
  bad "crystalcastle-notify:local not built"
fi

echo "== pdf2html image =="
if docker image inspect crystalcastle-pdf2html:local >/dev/null 2>&1; then
  docker run --rm --entrypoint pdf2htmlEX crystalcastle-pdf2html:local --version \
    >/dev/null 2>&1 && ok "pdf2htmlEX binary works" || bad "pdf2htmlEX not runnable"
else
  bad "crystalcastle-pdf2html:local not built"
fi

echo
echo "smoke: $pass passed, $fail failed"
exit $(( fail > 0 ))
