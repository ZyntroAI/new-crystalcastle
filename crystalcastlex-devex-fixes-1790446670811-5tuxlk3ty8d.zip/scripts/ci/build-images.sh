#!/usr/bin/env bash
# Build the three CrystalCastle images locally. Mirrors .github/workflows/container.yml.
#
#   scripts/ci/build-images.sh            # build all
#   scripts/ci/build-images.sh web        # build one
set -euo pipefail
cd "$(dirname "$0")/../.."

declare -A CTX=( [web]="." [notify]="notify_system" [pdf2html]="src/api/flask_pdf2htmlEX_drive" )
declare -A DF=( [web]="Dockerfile.web" [notify]="notify_system/Dockerfile" \
                [pdf2html]="src/api/flask_pdf2htmlEX_drive/Dockerfile" )

targets=("$@")
[ ${#targets[@]} -eq 0 ] && targets=(web notify pdf2html)

fail=0
for name in "${targets[@]}"; do
  ctx="${CTX[$name]:-}"; df="${DF[$name]:-}"
  if [ -z "$ctx" ]; then echo "unknown image: $name"; fail=1; continue; fi
  if [ ! -f "$df" ]; then
    echo "SKIP $name — missing $df"; fail=1; continue
  fi
  echo "==> building $name  (context=$ctx file=$df)"
  docker build -t "crystalcastle-$name:local" -f "$df" "$ctx" || fail=1
done
exit $fail
