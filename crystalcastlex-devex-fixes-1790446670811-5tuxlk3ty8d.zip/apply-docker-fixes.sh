#!/usr/bin/env bash
# =============================================================================
# CrystalCastle — apply the generated developer-experience fixes
#
#   ./apply-docker-fixes.sh --repo /path/to/crystalcastleX            # preview
#   ./apply-docker-fixes.sh --repo /path/to/crystalcastleX --apply    # write
#
# Idempotent. Never commits, never pushes, never runs docker.
# =============================================================================
set -uo pipefail

REPO=""; APPLY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --repo) REPO="$2"; shift 2 ;;
    --apply) APPLY=1; shift ;;
    *) echo "unknown arg: $1"; exit 2 ;;
  esac
done
[ -n "$REPO" ] || { echo "usage: $0 --repo <path> [--apply]"; exit 2; }
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO" || { echo "no such repo: $REPO"; exit 1; }
[ -d .git ] || { echo "not a git repo: $REPO"; exit 1; }

say() { printf '%s\n' "$*"; }
put() { # put <src> <dest>
  if [ "$APPLY" -eq 1 ]; then mkdir -p "$(dirname "$2")"; cp "$1" "$2"; say "  WROTE  $2"; 
  else say "  DRY    $2  <- $(basename "$1")"; fi
}

say "repo : $(pwd)"
say "mode : $([ "$APPLY" -eq 1 ] && echo APPLY || echo DRY-RUN)"
say ""

say "[1/6] Dockerfiles that did not exist"
put "$HERE/Dockerfile.web"                          "Dockerfile.web"
put "$HERE/notify_system/Dockerfile"                "notify_system/Dockerfile"
put "$HERE/src/api/flask_pdf2htmlEX_drive/Dockerfile" \
                                                    "src/api/flask_pdf2htmlEX_drive/Dockerfile"

say "[2/6] .dockerignore for the two new build contexts"
put "$HERE/dockerignore.web"                        ".dockerignore.web"
put "$HERE/notify_system/dockerignore"              "notify_system/.dockerignore"

say "[3/6] docker-compose.yml (rewritten against real services)"
put "$HERE/docker-compose.yml"                      "docker-compose.yml"

say "[4/6] root .gitignore (repo had none)"
if [ -f .gitignore ]; then say "  SKIP   .gitignore already exists"; 
else put "$HERE/gitignore" ".gitignore"; fi

say "[5/6] package/core/package.json (was a stub: no scripts, no deps, dead main)"
put "$HERE/package.core.json"                       "package/core/package.json"

say "[6/7] config schemas"
put "$HERE/notify_system__schemas__config.schema.json" \
                                                    "notify_system/schemas/config.schema.json"
put "$HERE/docs__knowledge__schemas__next-action.schema.json" \
                                                    "docs/knowledge/schemas/next-action.schema.json"

say "[7/7] container pipeline"
put "$HERE/.github/workflows/container.yml"         ".github/workflows/container.yml"
put "$HERE/scripts/ci/build-images.sh"              "scripts/ci/build-images.sh"
put "$HERE/scripts/ci/smoke-test.sh"                "scripts/ci/smoke-test.sh"
put "$HERE/Makefile"                                "Makefile"
[ "$APPLY" -eq 1 ] && chmod +x scripts/ci/*.sh

say ""
say "done. review with:  git status --short"
[ "$APPLY" -eq 1 ] || say "(re-run with --apply to write)"
