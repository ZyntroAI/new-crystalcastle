# CrystalCastle — developer-experience fixes

Grounded in the live tree of `zyntromedia/crystalcastleX` @ `main` (`752f5ed`).
Every change below cites the measured fact that motivated it.

## Apply it

```bash
./apply-docker-fixes.sh --repo /path/to/crystalcastleX            # preview
./apply-docker-fixes.sh --repo /path/to/crystalcastleX --apply    # write
```

Idempotent, dry-run by default, never commits or pushes, never invokes docker.

---

## 1. Dockerfiles — three that did not exist

| File | Target | Why it was needed |
|---|---|---|
| `Dockerfile.web` | Next.js app (repo root) | The only root `Dockerfile` runs `uvicorn src.main:app`; **`src/main.py` and `src/main/` are absent from the tree**, so it can never start. The web app had no image of its own. |
| `notify_system/Dockerfile` | `notify_system` Node ESM engine | Service has `"type":"module"` and a `start` script but no image. |
| `src/api/flask_pdf2htmlEX_drive/Dockerfile` | Flask pdf2htmlEX service | Replaces the committed `DockerFile` (capital F) which had no `USER` and no `HEALTHCHECK`. |

All three: multi-stage where useful, non-root `USER`, `HEALTHCHECK`, base images
pinned to an explicit tag (never `latest`).

**Node 20** is used because the repo's own `package.json` declares
`"engines": { "node": "20.x" }` and Next `15.5.24`.

## 2. `docker-compose.yml` — rewritten

The committed compose had five defects, all measured:

- `app: build: .` builds the root Dockerfile → dead `src.main:app` command
- `env_file: .env` → no `.env` is or should be committed
- `mock_ai` pulls `ghcr.io/pallets/helloworld:latest` — an unrelated image
- `volumes: ./:/app` bind-mounts the whole repo over the image
- hard-coded `POSTGRES_PASSWORD: crystalpass` in plaintext

The rewrite declares the services that actually exist (**web, notify, db, redis**),
uses `${POSTGRES_PASSWORD:?…}` so compose fails loudly instead of shipping a
known password, and adds healthchecks plus `depends_on: condition: service_healthy`.

> **Note:** `redis` is declared though nothing in the tree references it yet — it
> was in the original compose. Drop it if you do not intend to use it.

## 3. `.gitignore` — the repo had none

No root `.gitignore` existed, leaving `.env`, `node_modules`, `.next` and
`__pycache__` unprotected repo-wide. Template covers secrets, Node, Next,
build output, Python, and OS/editor files.

## 4. `package/core/package.json` — was a non-functional stub

```json
{ "name": "@ZyntroMedia/agent-core", "main": "index.ts", "types": "index.ts" }
```

That directory contains **`package.json` and nothing else** — the declared entry
point does not exist, and the file has no scripts and no dependencies. Rewritten
to be internally consistent (scoped name matching the root publisher, real
`scripts`, `devDependencies`, `private: true`).

## 5. JSON Schemas — rewritten against the code that reads them

**`notify_system/schemas/config.schema.json`** previously required a `triggers`
key that **no code path reads**, and required `system.logLevel` while the engine
also reads `system.logPath` (undeclared). A config the code actually runs on was
therefore *rejected* by its own schema. The rewrite declares exactly the fields
`src/*.js` consumes:

```
system.{name,version,logLevel,logPath}
channels.slack.{enabled,webhookUrl,defaultChannel}
channels.webhook.{enabled,url,secret}
rules.filter.{excludeEvents,minPriority}     minPriority enum = debug|info|warning|critical|success
rules.throttle.{enabled,windowSeconds}
```

`triggers` is kept but **optional**, so existing configs stay valid.

**`docs/knowledge/schemas/next-action.schema.json`** had `additionalProperties`
set to a *type object* where JSON Schema expects an *array* (`["string"]`), so it
did not constrain the `actions` map at all. Replaced with `propertyNames` +
`additionalProperties` over the real action enum.

## 6. The two corrupted-name workflow blobs

`workflows/` contains two entries whose **filename** carries the intended YAML
(git truncated at `NAME_MAX`) while the blob holds junk:

| Path bytes | Name stem | Blob was | Repaired to |
|---|---|---|---|
| 422 | `dependabot-auto-merge.yml` | `echo "test"` (11 B) | 387 B workflow |
| 435 | `name: DeploDeploy` | mangled 417 B | 475 B workflow |

The repair is **recovered from the filename**, not invented — the name is the
authoritative copy. The one place the name itself was truncated mid-expression
(`...inputs.environm`) is completed to its single unambiguous form.

## 7. Container pipeline

`.github/workflows/container.yml` — **build → smoke → push**, with every action
pinned to a **full 40-char commit SHA** resolved live from the GitHub API:

| Action | Tag | Pinned SHA |
|---|---|---|
| actions/checkout | v4 | `11d5960a326750d5838078e36cf38b85af677262` |
| actions/setup-qemu | v3 | `c7c53464625b32c7a7e944ae62b3e17d2b600130` |
| docker/setup-buildx-action | v3 | `8d2750c68a42422c14e847fe6c8ac0403b4cbd6f` |
| docker/build-push-action | v6 | `10e90e3645eae34f1e60eeb005ba3a3d33f178e8` |
| docker/login-action | v3 | `c94ce9fb468520275223c153574b00df6fe4bcc9` |
| actions/upload-artifact | v4 | `ea165f8d65b6e75b540449e92b4886f43607fa02` |
| actions/download-artifact | v4 | `d3f86a106a0bac45b974a628896c90dbdf5c8093` |

Pipeline shape:

- **matrix build** over the three real images (web / notify / pdf2html), BuildKit
  GHA cache per image, `load: true` so the smoke job can run the artifact
- **smoke job** (`needs: build`) starts the image against a real Postgres 15
  service, waits for readiness with a bounded loop, asserts the process is
  **not root**, and always tears down
- **push to GHCR** only on `push` (never on PR), tagging `$ref_name` and `latest`
- top-level `permissions: contents: read`; `packages: write` only on the build job
- `concurrency` cancel-in-progress so stale runs do not queue

Local parity — the same commands CI runs:

```bash
make docker.build     # scripts/ci/build-images.sh
make docker.smoke     # scripts/ci/smoke-test.sh  (asserts behaviour, not exit codes)
make docker.verify    # both
make docker.up/down/logs/clean
```

---

## Evidence files

- `junk_scan.json` — classification of every entry under both workflow dirs
- `schema_tests.json` — 13 schema validation checks (incl. the old schema failing)
- `docker_tests.json` — 24 static Dockerfile checks
- `pipeline_tests.json` — 19 pipeline checks (YAML, SHA pinning, script syntax, logic)
