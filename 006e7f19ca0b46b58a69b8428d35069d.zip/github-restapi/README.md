# GitHub REST API Proxy (FastAPI)

An async FastAPI service that wraps the GitHub REST API. Built to plug into a
`fastapi-python-boilerplate`-style project — drop the `app/` package in and go.

Every response uses a uniform envelope:

```json
{
  "data": { "...": "GitHub's raw JSON payload" },
  "rate_limit": { "x-ratelimit-limit": "5000", "x-ratelimit-remaining": "4999", "..." : "..." },
  "pagination": { "next": "https://api.github.com/...&page=2", "last": "..." }
}
```

`pagination` is `null` for single-resource endpoints.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # optional: add GITHUB_TOKEN
uvicorn app.main:app --reload
```

Open http://localhost:8000/docs for the interactive Swagger UI.

### Docker

```bash
docker build -t github-restapi .
docker run -p 8000:8000 --env-file .env github-restapi
```

## Authentication

Without a token: **60 requests/hour**, public repos only.
With a [Personal Access Token](https://github.com/settings/tokens) in `.env`:
**5000 requests/hour** + access to any private repo the token can read.

## Endpoints (all under `/api` by default)

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Liveness check |
| GET | `/api/users/{username}` | User / org profile |
| GET | `/api/users/{username}/repos` | List a user's repos |
| GET | `/api/users/{username}/orgs` | List a user's orgs |
| GET | `/api/repos/{owner}/{repo}` | Repo details |
| GET | `/api/repos/{owner}/{repo}/languages` | Language byte breakdown |
| GET | `/api/repos/{owner}/{repo}/contributors` | Contributors |
| GET | `/api/repos/{owner}/{repo}/commits` | Commits (filter by sha/path/author/since/until) |
| GET | `/api/repos/{owner}/{repo}/tags` · `/releases` · `/branches` | Tags / releases / branches |
| GET | `/api/repos/{owner}/{repo}/issues` | List issues |
| GET | `/api/repos/{owner}/{repo}/issues/{n}` | Single issue + `/comments` |
| GET | `/api/repos/{owner}/{repo}/pulls` | List PRs (filter by state/head/base) |
| GET | `/api/repos/{owner}/{repo}/pulls/{n}` | Single PR, plus `/files` and `/reviews` |
| GET | `/api/repos/{owner}/{repo}/actions/workflows` | List workflows |
| GET | `/api/repos/{owner}/{repo}/actions/runs` | List workflow runs |
| GET | `/api/repos/{owner}/{repo}/actions/runs/{run_id}` | **A single run** |
| GET | `/api/repos/{owner}/{repo}/actions/runs/{run_id}/jobs` | Jobs + step status for a run |
| GET | `/api/repos/{owner}/{repo}/actions/runs/{run_id}/timing` | Billable timing for a run |
| GET | `/api/search/repositories` · `/issues` · `/users` | GitHub search |

List endpoints accept `per_page` (1–100) and `page`.

## Example — the run from your link

```bash
# https://github.com/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712
curl "http://localhost:8000/api/repos/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712"
curl "http://localhost:8000/api/repos/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712/jobs"
```

> Note: `ZyntroAI/fastapi-python-boilerplate` is a private repo, so these calls
> require a `GITHUB_TOKEN` with access to that repo — otherwise GitHub returns 404.

## Error mapping

| GitHub | This API | Body |
|---|---|---|
| 403 + rate limit 0 | 429 | `{error, rate_limit}` |
| 404 | 404 | `{error, url}` |
| other 4xx/5xx | same code | `{error, rate_limit}` |

## Project layout

```
github-restapi/
├── app/
│   ├── main.py            # FastAPI app, CORS, router mounting
│   ├── config.py          # pydantic-settings from .env
│   ├── github_client.py   # async httpx client + error/rate-limit/pagination handling
│   └── routers/
│       ├── health.py
│       ├── users.py
│       ├── repos.py
│       ├── issues.py
│       ├── pulls.py
│       ├── actions.py     # workflow runs / jobs (the run view from your link)
│       └── search.py
├── requirements.txt
├── .env.example
├── Dockerfile
└── README.md
```
