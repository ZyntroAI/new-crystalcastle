from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client
from app.routers.repos import _clean

router = APIRouter(prefix="/repos/{owner}/{repo}/issues", tags=["issues"])


@router.get("", summary="List issues (pull requests excluded at GitHub level)")
async def list_issues(
    owner: str,
    repo: str,
    state: str = Query("open", pattern="^(open|closed|all)$"),
    labels: str | None = Query(None, description="Comma-separated label names"),
    sort: str = Query("created", pattern="^(created|updated|comments)$"),
    direction: str = Query("desc", pattern="^(asc|desc)$"),
    since: str | None = Query(None, description="ISO 8601 timestamp"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    params = _clean({"state": state, "labels": labels, "sort": sort, "direction": direction,
                     "since": since, "per_page": per_page, "page": page})
    return await client.get(f"/repos/{owner}/{repo}/issues", params=params)


@router.get("/{issue_number}", summary="Get a single issue by number")
async def get_issue(
    owner: str, repo: str, issue_number: int,
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/issues/{issue_number}")


@router.get("/{issue_number}/comments", summary="List comments on an issue")
async def list_issue_comments(
    owner: str, repo: str, issue_number: int,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/repos/{owner}/{repo}/issues/{issue_number}/comments",
        params={"per_page": per_page, "page": page},
    )
