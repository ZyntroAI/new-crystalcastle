from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/{username}", summary="Get a user or organization profile")
async def get_user(
    username: str,
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/users/{username}")


@router.get("/{username}/repos", summary="List public repositories for a user or org")
async def list_user_repos(
    username: str,
    type: str = Query("owner", pattern="^(all|owner|member)$"),
    sort: str = Query("updated", pattern="^(created|updated|pushed|full_name)$"),
    direction: str = Query("desc", pattern="^(asc|desc)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/users/{username}/repos",
        params={"type": type, "sort": sort, "direction": direction, "per_page": per_page, "page": page},
    )


@router.get("/{username}/orgs", summary="List organizations a user belongs to")
async def list_user_orgs(
    username: str,
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/users/{username}/orgs", params={"per_page": per_page, "page": page})
