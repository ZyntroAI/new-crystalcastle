"""GitHub Actions endpoints — including the exact run view from your link.

Your original URL:
  https://github.com/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712
maps to:
  GET /api/repos/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712
  GET /api/repos/ZyntroAI/fastapi-python-boilerplate/actions/runs/38909107712/jobs
"""
from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client
from app.routers.repos import _clean

router = APIRouter(prefix="/repos/{owner}/{repo}/actions", tags=["github actions"])


@router.get("/workflows", summary="List workflows in a repo")
async def list_workflows(
    owner: str, repo: str,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/actions/workflows", params={"per_page": per_page, "page": page})


@router.get("/runs", summary="List workflow runs")
async def list_workflow_runs(
    owner: str,
    repo: str,
    branch: str | None = Query(None, description="Filter by branch"),
    event: str | None = Query(None, description="e.g. push, pull_request, workflow_dispatch"),
    status: str | None = Query(
        None, description="queued|in_progress|completed|success|failure|cancelled|timed_out"
    ),
    created: str | None = Query(None, description="ISO 8601 or range, e.g. >=2026-01-01"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    params = _clean({"branch": branch, "event": event, "status": status, "created": created,
                     "per_page": per_page, "page": page})
    return await client.get(f"/repos/{owner}/{repo}/actions/runs", params=params)


@router.get("/runs/{run_id}", summary="Get a single workflow run by id")
async def get_workflow_run(
    owner: str, repo: str, run_id: int,
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/actions/runs/{run_id}")


@router.get("/runs/{run_id}/jobs", summary="List jobs (and step logs status) for a run")
async def list_run_jobs(
    owner: str, repo: str, run_id: int,
    filter: str = Query("latest", pattern="^(latest|all)$"),
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/repos/{owner}/{repo}/actions/runs/{run_id}/jobs",
        params={"filter": filter, "per_page": per_page, "page": page},
    )


@router.get("/runs/{run_id}/timing", summary="Get timing (billable seconds) for a run")
async def get_run_timing(
    owner: str, repo: str, run_id: int,
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/actions/runs/{run_id}/timing")
