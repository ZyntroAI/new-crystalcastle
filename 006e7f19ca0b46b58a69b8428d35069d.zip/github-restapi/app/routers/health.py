from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health", summary="Liveness / readiness check")
async def health_check() -> dict:
    return {"status": "ok", "service": "github-restapi"}
