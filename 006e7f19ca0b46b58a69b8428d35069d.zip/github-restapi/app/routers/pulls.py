from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client
from app.routers.repos import _clean

router = APIRouter(prefix="/repos/{owner}/{repo}/pulls", tags=["pull requests"])


@router.get("", summary="List pull requests")
async def list_pulls(
    owner: str,
    repo: str,
    state: str = Query("open", pattern="^(open|closed|all)$"),
    head: str | None = Query(None, description="Filter by head user:branch"),
    base: str | None = Query(None, description="Filter by base branch"),
    sort: str = Query("created", pattern="^(created|updated|popularity|long-running)$"),
    direction: str = Query("desc", pattern="^(asc|desc)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    params = _clean({"state": state, "head": head, "base": base, "sort": sort,
                     "direction": direction, "per_page": per_page, "page": page})
    return await client.get(f"/repos/{owner}/{repo}/pulls", params=params)


@router.get("/{pull_number}", summary="Get a single pull request")
async def get_pull(
    owner: str, repo: str, pull_number: int,
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/pulls/{pull_number}")


@router.get("/{pull_number}/files", summary="List files changed in a PR")
async def list_pull_files(
    owner: str, repo: str, pull_number: int,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/repos/{owner}/{repo}/pulls/{pull_number}/files",
        params={"per_page": per_page, "page": page},
    )


@router.get("/{pull_number}/reviews", summary="List reviews on a PR")
async def list_pull_reviews(
    owner: str, repo: str, pull_number: int,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/repos/{owner}/{repo}/pulls/{pull_number}/reviews",
        params={"per_page": per_page, "page": page},
    )
