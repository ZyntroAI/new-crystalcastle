from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client
from app.routers.repos import _clean

router = APIRouter(prefix="/search", tags=["search"])


@router.get("/repositories", summary="Search repositories")
async def search_repositories(
    q: str = Query(..., description="GitHub search query, e.g. fastapi language:python stars:>1000"),
    sort: str = Query("stars", pattern="^(stars|forks|help-wanted-issues|updated)$"),
    order: str = Query("desc", pattern="^(asc|desc)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get("/search/repositories", params=_clean(
        {"q": q, "sort": sort, "order": order, "per_page": per_page, "page": page}))


@router.get("/issues", summary="Search issues and pull requests")
async def search_issues(
    q: str = Query(..., description="e.g. repo:owner/repo is:pr is:open"),
    sort: str = Query("created", pattern="^(comments|reactions|reactions-+1|reactions--1|reactions-smile|reactions-thinking_face|reactions-heart|reactions-tada|interactions|created|updated)$"),
    order: str = Query("desc", pattern="^(asc|desc)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get("/search/issues", params=_clean(
        {"q": q, "sort": sort, "order": order, "per_page": per_page, "page": page}))


@router.get("/users", summary="Search users")
async def search_users(
    q: str = Query(..., description="e.g. zyntro type:org"),
    sort: str = Query("followers", pattern="^(followers|repositories|joined)$"),
    order: str = Query("desc", pattern="^(asc|desc)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get("/search/users", params=_clean(
        {"q": q, "sort": sort, "order": order, "per_page": per_page, "page": page}))
