from fastapi import APIRouter, Depends, Query

from app.github_client import GitHubClient, get_github_client

router = APIRouter(prefix="/repos", tags=["repositories"])


def _clean(params: dict) -> dict:
    return {k: v for k, v in params.items() if v is not None}


@router.get("/{owner}/{repo}", summary="Get repository details")
async def get_repo(owner: str, repo: str, client: GitHubClient = Depends(get_github_client)):
    return await client.get(f"/repos/{owner}/{repo}")


@router.get("/{owner}/{repo}/languages", summary="Get language byte breakdown for a repo")
async def get_languages(owner: str, repo: str, client: GitHubClient = Depends(get_github_client)):
    return await client.get(f"/repos/{owner}/{repo}/languages")


@router.get("/{owner}/{repo}/contributors", summary="List contributors")
async def list_contributors(
    owner: str,
    repo: str,
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(
        f"/repos/{owner}/{repo}/contributors", params={"per_page": per_page, "page": page}
    )


@router.get("/{owner}/{repo}/commits", summary="List commits (filterable by branch/path/author/date)")
async def list_commits(
    owner: str,
    repo: str,
    sha: str | None = Query(None, description="Branch, tag, or commit SHA"),
    path: str | None = Query(None, description="Only commits touching this file path"),
    author: str | None = Query(None, description="GitHub username or email"),
    since: str | None = Query(None, description="ISO 8601 timestamp, e.g. 2026-01-01T00:00:00Z"),
    until: str | None = Query(None, description="ISO 8601 timestamp"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    params = _clean({"sha": sha, "path": path, "author": author, "since": since, "until": until,
                     "per_page": per_page, "page": page})
    return await client.get(f"/repos/{owner}/{repo}/commits", params=params)


@router.get("/{owner}/{repo}/tags", summary="List tags")
async def list_tags(
    owner: str, repo: str,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/tags", params={"per_page": per_page, "page": page})


@router.get("/{owner}/{repo}/releases", summary="List releases")
async def list_releases(
    owner: str, repo: str,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/releases", params={"per_page": per_page, "page": page})


@router.get("/{owner}/{repo}/branches", summary="List branches")
async def list_branches(
    owner: str, repo: str,
    per_page: int = Query(30, ge=1, le=100), page: int = Query(1, ge=1),
    client: GitHubClient = Depends(get_github_client),
):
    return await client.get(f"/repos/{owner}/{repo}/branches", params={"per_page": per_page, "page": page})
