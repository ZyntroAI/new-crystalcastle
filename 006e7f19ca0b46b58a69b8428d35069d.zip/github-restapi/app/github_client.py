"""Async HTTP client wrapping the GitHub REST API.

Every successful response is returned in a uniform envelope:
    {
        "data": <GitHub JSON payload>,
        "rate_limit": {limit, remaining, reset, used},
        "pagination": {next, last, first, prev} | None
    }

GitHub errors are mapped to FastAPI HTTPExceptions with a useful detail body.
"""
from __future__ import annotations

import re

import httpx
from fastapi import Depends, HTTPException

from app.config import Settings, get_settings

_RATE_HEADERS = (
    "x-ratelimit-limit",
    "x-ratelimit-remaining",
    "x-ratelimit-reset",
    "x-ratelimit-used",
    "x-ratelimit-resource",
)


def _parse_link_header(link: str) -> dict[str, str]:
    """Parse GitHub's `Link` pagination header into {rel: url}."""
    out: dict[str, str] = {}
    for segment in link.split(","):
        m = re.search(r'<([^>]+)>;\s*rel="([^"]+)"', segment.strip())
        if m:
            out[m.group(2)] = m.group(1)
    return out


class GitHubClient:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._base = settings.github_api_base.rstrip("/")

    @property
    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "github-restapi-proxy",
        }
        if self._settings.github_token:
            headers["Authorization"] = f"Bearer {self._settings.github_token}"
        return headers

    async def get(self, path: str, params: dict | None = None) -> dict:
        url = f"{self._base}/{path.lstrip('/')}"
        async with httpx.AsyncClient(
            timeout=self._settings.request_timeout, follow_redirects=True
        ) as client:
            resp = await client.get(url, headers=self._headers, params=params)
        return self._handle(resp)

    def _handle(self, resp: httpx.Response) -> dict:
        rate_limit = {h: resp.headers.get(h) for h in _RATE_HEADERS}

        # Rate limit exhaustion -> 429 with reset info
        if (
            resp.status_code == 403
            and rate_limit.get("x-ratelimit-remaining") == "0"
        ):
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "GitHub API rate limit exceeded",
                    "rate_limit": rate_limit,
                },
            )

        # 404 = private repo (no token) or genuinely missing resource
        if resp.status_code == 404:
            raise HTTPException(
                status_code=404,
                detail={
                    "error": "GitHub resource not found (invalid id, or private repo without a token)",
                    "url": str(resp.url),
                },
            )

        # Any unhandled 3xx (shouldn't happen with follow_redirects) -> 502;
        # 4xx/5xx -> pass through upstream status.
        if resp.status_code >= 300:
            try:
                message = resp.json().get("message", resp.text)
            except ValueError:
                message = resp.text
            upstream_code = resp.status_code
            code = upstream_code if 400 <= upstream_code < 600 else 502
            raise HTTPException(
                status_code=code,
                detail={
                    "error": message,
                    "upstream_status": upstream_code,
                    "rate_limit": rate_limit,
                },
            )

        pagination = _parse_link_header(resp.headers["link"]) if resp.headers.get("link") else None

        return {
            "data": resp.json(),
            "rate_limit": rate_limit,
            "pagination": pagination,
        }


async def get_github_client(settings: Settings = Depends(get_settings)) -> GitHubClient:
    return GitHubClient(settings)
