"""Application configuration loaded from environment variables / .env file."""
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Optional GitHub Personal Access Token (classic or fine-grained).
    # Without it: 60 req/hour rate limit, public repos only.
    # With it: 5000 req/hour, plus access to private repos the token can see.
    github_token: str | None = Field(default=None, alias="GITHUB_TOKEN")

    github_api_base: str = Field(default="https://api.github.com", alias="GITHUB_API_BASE")
    api_prefix: str = Field(default="/api", alias="API_PREFIX")

    # JSON-encoded list, e.g. CORS_ORIGINS='["http://localhost:3000"]'
    cors_origins: list[str] = Field(default_factory=lambda: ["*"], alias="CORS_ORIGINS")

    request_timeout: float = Field(default=30.0, alias="REQUEST_TIMEOUT")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
