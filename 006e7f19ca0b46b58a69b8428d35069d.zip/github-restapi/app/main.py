"""FastAPI entrypoint — GitHub REST API proxy.

Run locally:
    uvicorn app.main:app --reload
Then open http://localhost:8000/docs for the interactive Swagger UI.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

from app.config import get_settings
from app.routers import actions, health, issues, pulls, repos, search, users

settings = get_settings()

app = FastAPI(
    title="GitHub REST API Proxy",
    version="1.0.0",
    description=(
        "Async FastAPI wrapper around the GitHub REST API. "
        "Every response is wrapped in `{data, rate_limit, pagination}`. "
        "Set `GITHUB_TOKEN` in `.env` to raise the rate limit and access private repos. "
        "All endpoints live under the configured `API_PREFIX` (default `/api`)."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health at root (no prefix) for load balancers
app.include_router(health.router)

prefix = settings.api_prefix
app.include_router(users.router, prefix=prefix)
app.include_router(repos.router, prefix=prefix)
app.include_router(issues.router, prefix=prefix)
app.include_router(pulls.router, prefix=prefix)
app.include_router(actions.router, prefix=prefix)
app.include_router(search.router, prefix=prefix)


@app.get("/", include_in_schema=False)
async def root() -> RedirectResponse:
    return RedirectResponse(url="/docs")
